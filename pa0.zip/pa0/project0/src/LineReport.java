import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.stream.Collectors;

// This is where most of the stuff is going down
public class LineReport {

public static void main(String[] args) throws IOException {
		
	// Remember to eventually change this. 
    ArrayList<String> names = new ArrayList<>(); // Will store the usernames here
        
    Scanner inputFilename = new Scanner(System.in); 
    String s = inputFilename.nextLine(); //C:\\testing.txt

    //Put s below to read from a file. 
    BufferedReader in = new BufferedReader(new FileReader(s));
    String str;
    Usage nameList = new Usage();
    LineUsage object = new LineUsage();

    
    ArrayList<String> list = new ArrayList<String>();
    while((str = in.readLine()) != null){
        nameList.setUsername(str); // Encapsulating the username here. 
        list.add(nameList.getUsername());
    }

    String[] stringArr = list.toArray(new String[0]);
      
    TreeMap<String, Integer> map = new TreeMap<>(); // Will index line and username
    
    for (String key : stringArr)
    {
      Integer count = map.get(key);
      
      if (count == null)
      {
    	  
    	// Make oop out of this variable. 
        count = 0; // using java autoboxing.
        
      }
      nameList.setCount(++count); // Encapsulating the count here
      map.put(key, nameList.getCount()); // incrementing by 1 before storing in the Map
       //Storing the count in the class. 
    }
    
    // Sorting the TreeMap here.          
    Map<String, Integer> hm1 = sortByValue(map); 
    
    Set<String> keys = hm1.keySet(); // Maybe sort the set instead
            
    // Try to see what happens here. 
    ArrayList<String> keyList = new ArrayList<String>(hm1.keySet()); // Will break this one into two other list 
    ArrayList<Integer> valueList = new ArrayList<Integer>(hm1.values()); 
    
    int n = keyList.size();
    
    String[] array = new String[n];
    for(int i = 0; i < n; i++) array[i] = keyList.get(i);
    
    //for(int i = 0; i < n; i++) System.out.println(i + " " + array[i]);
    // Breaking the array in two so that they can be stored in new lists. 
    
    String[][] sort = sortNames(array);
    String[] line_number = sort[0]; // Line Count
    String[] user_name = sort[1]; // User Names
    
    // Turning the arrays into ArrayList
    
    List<String> lineNumber = Arrays.asList(line_number);  
    List<Integer> integerList = lineNumber.stream()
            .map(Integer::valueOf).collect(Collectors.toList());    
    
    List<String> userName = Arrays.asList(user_name);  
    
    for (int i = 0; i < integerList.size(); i++) {
    	  //nameList.mapUser.put(integerList.get(i), userName.get(i));
    	  object.sendInfo(integerList.get(i), userName.get(i));
    }          
            
    /*System.out.println("The map with the usernames and line");
    object.printMap1();
    System.out.println("");
	*/
    // This one will be with in the Usage class to keep username and count together. 
    //HashMap<Integer, Integer> mapCount = new HashMap<>(); // Maybe fill in the hashmap. 
    
    for (int i = 0; i < integerList.size(); i++) {
  	 // object.mapCount.put(integerList.get(i), valueList.get(i)); for public hashmap in LineUsage class
    	object.sendInfo2(integerList.get(i), valueList.get(i));
  	}   
    
    //System.out.println("The map with the line and count for the users.");
    //object.printMap2();
    
    HashMap <Integer, String> username = object.getMap1();
	HashMap <Integer, Integer> lineCount = object.getMap2();
	
	// The ArrayList<LineUsage> finalList holds the final results of users in each terminal. 
	ArrayList<LineUsage> finalList = new ArrayList<>();

	for(int i = 0; i < 501; i++) {
		finalList.add(i, new LineUsage(i,"NONE", 0));
	}
	
	for(int i = 1; i < 501; i++){
		
		if(username.get(i) != null)			
		finalList.set(i ,new LineUsage(i, username.get(i) ,lineCount.get(i)));	
		if(finalList.get(i) == null) {
			
            finalList.set(i, new LineUsage(i, "NONE", 0));
		}			
	 }	
	
	finalList.remove(0); // Removing the zero index. 

    System.out.println("Line Most Common User Count");    
    for(int i = 0; i < 1;i++)
     
    	for(LineUsage human : finalList) {
    		
    	System.out.printf("%-4d %-10s %-20d%n", human.line(), human.name(), human.lineAppearances());    	
    	}   
}
   	
// Sorting the TreeMap by the value. Higher values appear below. This helps with retriving 
// CITATION URL: https://www.geeksforgeeks.org/sorting-a-hashmap-according-to-values/
public static HashMap<String, Integer> sortByValue(TreeMap<String, Integer> map) 
{ 
    // Create a list from elements of HashMap 
    LinkedList<Entry<String, Integer>> list = 
           new LinkedList<Map.Entry<String, Integer> >(map.entrySet()); 

    // Sort the list 
    Collections.sort(list, new Comparator<Map.Entry<String, Integer> >() { 
        public int compare(Map.Entry<String, Integer> o1,  
                           Map.Entry<String, Integer> o2) 
        { 
            return (o1.getValue()).compareTo(o2.getValue()); 
        } 
    }); 
      
    // put data from sorted list to hashmap  
    HashMap<String, Integer> temp = new LinkedHashMap<String, Integer>(); 
    for (Map.Entry<String, Integer> aa : list) { 
        temp.put(aa.getKey(), aa.getValue()); 
    } 
    return temp; 
  } 
// CITATION URL: https://stackoverflow.com/questions/51471325/split-string-each-element-in-an-array-into-multiple-arrays/51471389
// This function below sorts the arrays of the names found of the list in order. 
public static String[][] sortNames(String[] info) {
    int infoArrLength = info.length;
    String[][] names = new String[2][infoArrLength];
    for(int i = 0; i < infoArrLength; i++) {
      String[] infos = info[i].split("\\s+");
      names[0][i] = infos[0];
      names[1][i] = infos[1];
    }
    return names;
  } 
}
