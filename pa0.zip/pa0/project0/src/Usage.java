import java.util.ArrayList;
import java.util.HashMap;

public class Usage {
	
	private int count;
	private String Username;
	
	HashMap<Integer, String> mapUser= new HashMap<Integer, String>();
	
	// Default constructor.
	public Usage() {
		
	}
	
	public Usage(String user, int number) {
		
		this.Username = user;
		this.count = number;		
	}
	
	public String getUsername() {
		return Username;
	}
	
	public void setUsername(String username) {
		Username = username;
	}
	
	public int getCount() {
		return count;
	}
	
	public void setCount(int count) {
		this.count = count;
	}
	public int increment() {
		
		return count++;		
	}	
}
