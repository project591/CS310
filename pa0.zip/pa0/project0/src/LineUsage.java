
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

// This is for testing out your program. 

public class LineUsage {
	
	private String Username;
	private int lineCount;
	private int lineNumber;
	//private Usage.object = new Usage();
	
	// Calling it hold for now. 
	private HashMap<Integer, Integer> mapCount = new HashMap<Integer, Integer>(); // contain final data of line count.
	private HashMap<Integer, String> userName = new HashMap<Integer, String>(); // contains final data on max user on line.
	
	
	LineUsage(){
		
	}
	
	LineUsage(int lineAt, String name, int lineTimes){
		
		this.lineCount = lineTimes;
		this.Username = name;
		this.lineNumber = lineAt;
	}
	
	// An example here on how im going to do this. 
	public void sendInfo(Integer integer, String string) {
				
		userName.put(integer, string);
	}
	
	// Could be used to test things I guess. But im still keeping some of the regular code. 
	public void printMap1() {
		
		System.out.print(userName);		
		
	}
	
	public void sendInfo2(int lineNumber, int lineCount) {
		
		mapCount.put(lineNumber, lineCount);
	}
	
	// Could be used to test things I guess. But im still keeping some of the regular code. 
	public void printMap2() {
		
		System.out.print(mapCount);		
		
	}
	
	// returns the map
	 public HashMap<Integer, String> getMap1() {
         return userName;
    }
	 
	public HashMap<Integer, Integer> getMap2(){
		return mapCount;	
		
	}
	
	public int line(){
		
		return this.lineNumber;
	}
	
	public String name() {
	    return this.Username;
	}
	
	public int lineAppearances() {
		return this.lineCount;
	}
}				


