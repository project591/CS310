package cs310.games;
import java.util.Scanner;

public class PlayGame {
	public PlayGame(Game g) {
		this.g = g;
	}

	public void doComputerMove() {
		g.printBoard();
		BestMove compMove = g.chooseMove(Game.COMPUTER, 0);
		System.out.println("Computer plays ROW = " + compMove.i + " COL = " + compMove.j);
		g.makeMove(Game.COMPUTER, compMove.i, compMove.j);
	}

	public void doHumanMove() {
		boolean legal;
		g.printBoard();
		do {
			System.out.println("i: ");   // or "row:", since both have rows
			int row = scan.nextInt();
			System.out.println("j: ");
			int col = scan.nextInt();
			legal = g.makeMove(Game.HUMAN, row, col);
			if (!legal)
				System.out.println("Illegal move, try again");
		} while (!legal);
	}
	
	// return true if game is continuing, false if done
	boolean checkAndReportStatus() {
		if (g.isWinner(Game.COMPUTER)) {
			System.out.println("Computer says: I WIN!!");
			return false; // game is done
		}
		if (g.isWinner(Game.HUMAN)) {
			System.out.println("Computer says: You WIN!!");
			return false; // game is done
		}
		if (g.isDraw()) {
			System.out.println(" Game is a DRAW");
			return false;
		}
		return true;
	}

	// do one round of playing the game, return true at end of game
	public boolean getAndMakeMoves() {
		// let computer go first...
		doComputerMove();
		if (!checkAndReportStatus())
			return false; // game over
		doHumanMove();
		if (!checkAndReportStatus())
			return false;
		return true;
	}
	
	void playOneGame() {
		boolean continueGame = true;
		g.init();
		while (continueGame) {
			continueGame = getAndMakeMoves();
		}
	}

	public static void main(String[] args) {
		Game g;
		if (args.length > 0 && args[0].equals("Nim"))
			g = new Nim4();
		else g = new TicTacToe4();
		PlayGame ui = new PlayGame(g);
		ui.playOneGame();
		scan.close();
	}

	private Game g;
	// static so we can use it in main too
	private static Scanner scan = new Scanner(System.in);
}
