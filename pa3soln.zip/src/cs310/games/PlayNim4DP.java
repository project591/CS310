package cs310.games;
import java.util.Scanner;

public class PlayNim4DP {
	public PlayNim4DP() {
		g = new Nim4DP();
	}

	public void doComputerMove() {
		g.printBoard();
		BestMove compMove = g.chooseMove(Nim3.COMPUTER, 0);
		System.out.println("Computer plays ROW = " + compMove.i + " STARS = " + compMove.j);
		g.makeMove(Nim3.COMPUTER, compMove.i, compMove.j);
	}

	public void doHumanMove() {
		boolean legal;
		g.printBoard();
		do {
			System.out.println("row: ");
			int row = scan.nextInt();
			System.out.println("stars: ");
			int col = scan.nextInt();
			legal = g.makeMove(Nim3.HUMAN, row, col);
			if (!legal)
				System.out.println("Illegal move, try again");
		} while (!legal);
	}

	boolean checkAndReportStatus() {
		if (g.isWinner(Nim3.COMPUTER)) {
			System.out.println("Computer says: I WIN!!");
			return false; // game is done
		}
		if (g.isWinner(Nim3.HUMAN)) {
			System.out.println("Computer says: You WIN!!");
			return false; // game is done
		}
		return true;
	}

	// do one round of playing the game, return true at end of game
	public boolean getAndMakeMoves() {
		// let computer go first...
		doComputerMove();
		if (!checkAndReportStatus())
			return false; // game over
		doHumanMove();
		if (!checkAndReportStatus())
			return false;
		return true;
	}

	void playOneGame() {
		boolean continueGame = true;
		g.init();
		while (continueGame) {
			continueGame = getAndMakeMoves();
		}
	}

	public static void main(String[] args) {
		PlayNim4DP ui = new PlayNim4DP();
		ui.playOneGame();
	}

	private Nim4DP g;
	private Scanner scan = new Scanner(System.in);
}
