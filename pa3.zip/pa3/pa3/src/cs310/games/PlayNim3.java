package cs310.games;

import java.util.Scanner;

public class PlayNim3 {
	public PlayNim3() {
		g = new Nim3();
	}
	// Copy from PlayTicTactoe1
	public void doComputerMove() {
		// Need to implement that Best choosemove for the 
		//g.printBoard();  // TODO: call TicTacToe's printBoard here
		BestMove compMove = g.chooseMove(Nim3.COMPUTER, 0); 
		// put makemove in here again. things will be done in terms of makemove
		// but with BestMove compMove. 
				
		System.out.println("Computer plays ROW = " + compMove.row + " COL = " + compMove.column);
		g.makeMove(Nim.COMPUTER, compMove.row, compMove.column);
				
	}
	
	public void doHumanMove() {
		boolean legal;
		g.toString();  // TODO: call TicTacToe's printBoard here

		do {
			System.out.println(g);
			System.out.println("row: ");
			int row = scan.nextInt();
			System.out.println("column: ");
			int col = scan.nextInt();
			legal = g.makeMove(Nim3.HUMAN, row, col); // ?
			if (!legal)
				System.out.println("Illegal move, try again");
		} while (!legal);
	}
	
	// return true if game is continuing, false if done
	boolean checkAndReportStatus() {
		if (g.isWin(Nim3.COMPUTER)) {
			System.out.println("Computer says: I WIN!!");
			return false; // game is done
		}
		if (g.isWin(Nim3.HUMAN)) {
			System.out.println("Computer says: You WIN!!");
			return false; // game is done
		}
		/*if (g.isDraw()) {
			System.out.println(" Game is a DRAW");
			return false;
		}*/
		System.out.println("game continuing");
		return true;
	}

	// do one round of playing the game, return true at end of game
	public boolean getAndMakeMoves() {
		// let computer go first...
		doComputerMove();
		System.out.println("back from doComputerMove");
		// System.out.println("count = " + t.getCount());
		if (!checkAndReportStatus())
			return false; // game over
		doHumanMove();
		if (!checkAndReportStatus())
			return false; // game over
		return true;
	}

	void playOneGame() {
		boolean continueGame = true;
		//g.clearBoard(); // ? clear not sure about this one.
		g.init();
		while (continueGame) {
			continueGame = getAndMakeMoves();
		}
	}

	public static void main(String[] args) {
		// You do the moves here I think. Look at PlayTicTacToe
		PlayNim3 ui = new PlayNim3();
		ui.playOneGame(); // is this doing anything to start the game. 
	}

	private Nim3 g; // g for game
	private Scanner scan = new Scanner(System.in);
	//private String computerSide = "O";
	//private String humanSide = "X";

}
