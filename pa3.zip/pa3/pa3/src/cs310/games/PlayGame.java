package cs310.games;

import java.util.*;


// combine everything here. 
public class PlayGame {
	
	    private final static String TIC_TAC_TOE = "TicTacToe";
	    private final static String NIM = "Nim";
	    private static Game game; 
	    private final static Scanner scan = new Scanner(System.in);
	    private String GAME_CHOICE;

	    public PlayGame(String choice) {
	        // conditions to check which game is chosen
	        if (choice.equals(NIM))
	            game = new Nim4();
	        else
	            game = new TicTacToe4();

	        this.GAME_CHOICE = choice;
	    }

	    // function to do the computer move
	    public void doComputerMove() {
	        printBoard();
	        BestMove compMove = game.chooseMove(Game.COMPUTER, 0); // depth 0 call
	        System.out.println("Computer plays ROW = " + compMove.row + (GAME_CHOICE.equals(TIC_TAC_TOE) ? " COL = " : " STARS = ") + compMove.column);
	        game.makeMove(Game.COMPUTER, compMove.row, compMove.column);
	    }

	    // function to do the human move
	    public void doHumanMove() {
	        boolean legal;
	        printBoard();
	        if (GAME_CHOICE.equals(NIM)) {
	            int ROW;
	            int SIZE;
	            System.out.println("(HUMAN DOING MOVE):"); 
	            do {
	                System.out.print("Choose row :");
	                ROW = scan.nextInt();
	                System.out.print("Choose stars to remove :");
	                SIZE = scan.nextInt();
	                if ((ROW < 0 || ROW > 2) || (SIZE > 5 || SIZE < 0))
	                    System.out.println("INVALID CHOICES! PLEASE TRY AGAIN!");
	            } while ((ROW < 0 || ROW > 2) || (SIZE > 5 || SIZE < 0));
	            game.makeMove(Game.HUMAN, ROW, SIZE);
	            printBoard();
	        } else {
	            do {
	                System.out.println("row: ");
	                int row = scan.nextInt();
	                System.out.println("column: ");
	                int col = scan.nextInt();
	                legal = game.makeMove(Game.HUMAN, row, col);
	                if (!legal)
	                    System.out.println("Illegal move, try again");
	            } while (!legal);
	        }
	    }

	    // return true if game is continuing, false if done
	    public boolean checkAndReportStatus() {
	        if (game.isWin(Game.COMPUTER)) {
	            System.out.println("Computer says: I WIN!!");
	            return false; // game is done
	        }
	        if (game.isWin(Game.HUMAN)) {
	            System.out.println("Computer says: You WIN!!");
	            return false; // game is done
	        }
	        if (game.isDraw()) {
	            System.out.println(" Game is a DRAW");
	            return false;
	        }
	        System.out.println("game continuing");
	        return true;
	    }

	    // do one round of playing the game, return true at end of game
	    public boolean getAndMakeMoves() {
	        doComputerMove();
	        System.out.println("back from doComputerMove");
	        if (!checkAndReportStatus())
	            return false; // game over
	        doHumanMove();
	        if (!checkAndReportStatus())
	            return false; // game over
	        return true;
	    }

	    public void printBoard() {
	        System.out.println(game);
	    }

	    // function to start the game
	    public void playOneGame() {
	        boolean continueGame = true;
	        game.init();
	        while (continueGame) {
	            continueGame = getAndMakeMoves();
	        }
	    }

	    public static void main(String args[]) {
	        
	        String choice = TIC_TAC_TOE;

	        // check to see if there is an argument passed in
	        if (!(args.length == 0)) {
	            if (args[0].equals(NIM))
	                choice = NIM;
	            else{
	                System.out.println("ERROR: Incorrect input to start game.");
	                return;
	            }
	        }
	        
	        PlayGame ui = new PlayGame(choice);
	        ui.playOneGame();
	    }	
	  
}
