package cs310.games;

// Putting the constants here. 


// The methods that are to implemented in 
// Nim4.java and TicTacToe4.java
interface Game {
	
	static final int HUMAN = 0; 
	static final int COMPUTER = 1;	
	static final int HUMAN_WIN = 0;
	static final int COMPUTER_WIN = 3;
		
	void init();
	boolean isDraw(); 
	int positionValue();
	boolean isWin(int side); 
	BestMove chooseMove(int side, int depth); 
	boolean makeMove(int side, int row, int number);
}
