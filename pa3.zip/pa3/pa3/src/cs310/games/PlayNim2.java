package cs310.games;

import java.util.Scanner;

public class PlayNim2 {
	public PlayNim2() {
		g = new Nim();
	}
	// Copy from PlayTicTactoe1
	public void doComputerMove() {
		boolean legal;
		g.toString();  // TODO: call TicTacToe's printBoard here

		do {
			System.out.println(g);
			System.out.println("row: ");
			int row = scan.nextInt();
			System.out.println("column: ");
			int col = scan.nextInt();
			legal = g.makeMove(Nim.COMPUTER, row, col); // ?
			if (!legal)
				System.out.println("Illegal move, try again");
		} while (!legal);
	}
		
	public void doHumanMove() {
		boolean legal;
		g.toString();  // TODO: call TicTacToe's printBoard here

		do {
			System.out.println(g);
			System.out.println("row: ");
			int row = scan.nextInt();
			System.out.println("column: ");
			int col = scan.nextInt();
			legal = g.makeMove(Nim.HUMAN, row, col); // ?
			if (!legal)
				System.out.println("Illegal move, try again");
		} while (!legal);
	}
	
	// return true if game is continuing, false if done
	boolean checkAndReportStatus() {
		if (g.isWin(Nim.COMPUTER)) {
			System.out.println("Computer says: I WIN!!");
			return false; // game is done
		}
		if (g.isWin(Nim.HUMAN)) {
			System.out.println("Computer says: You WIN!!");
			return false; // game is done
		}
		/*if (g.isDraw()) {
			System.out.println(" Game is a DRAW");
			return false;
		}*/
		System.out.println("game continuing");
		return true;
	}

	// do one round of playing the game, return true at end of game
	public boolean getAndMakeMoves() {
		// let computer go first...
		doComputerMove();
		System.out.println("back from doComputerMove");
		// System.out.println("count = " + t.getCount());
		if (!checkAndReportStatus())
			return false; // game over
		doHumanMove();
		if (!checkAndReportStatus())
			return false; // game over
		return true;
	}

	void playOneGame() {
		boolean continueGame = true;
		//g.clearBoard(); // ? clear not sure about this one.
		g.init();
		while (continueGame) {
			continueGame = getAndMakeMoves();
		}
	}

	public static void main(String[] args) {
		// You do the moves here I think. Look at PlayTicTacToe
		PlayNim2 ui = new PlayNim2();
		ui.playOneGame(); // is this doing anything to start the game. 
	}

	private Nim g; // g for game
	private Scanner scan = new Scanner(System.in);
	//private String computerSide = "O";
	//private String humanSide = "X";

}
