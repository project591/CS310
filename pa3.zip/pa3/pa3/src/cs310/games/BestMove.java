package cs310.games;

// So what do I do here now. 
final class BestMove
{
    int row;
    int column;
    int val;
    
    // value-only constructor: no position information
    public BestMove( int v )
      { this( v, -6, -7 ); }  // provide illegal position to detect accidental use
      
    public BestMove( int v, int r, int c )
      { val = v; row = r; column = c; }
}
