import edu.princeton.cs.algs4.*;

public class ShortestWPath {
    private PlatformGraph mG;
    private int initial_weight = 1;
    private int station_cost = 3;
    private int transfer_cost = 7;
    public ShortestWPath(PlatformGraph mGraph) {
        mG = mGraph;
    }
   
    public EdgeWeightedDigraph getEdgeWeightedDigraph() {
        Digraph G = mG.getGraph();
        EdgeWeightedDigraph dirG = new EdgeWeightedDigraph(G.V());
        Platform[] platforms = mG.getAllOfThePlatforms(); 
        for (int i = 1; i < G.V(); i++) {
            for (int j : G.adj(i)) {
                if (i < j) { 
                    double weight = initial_weight; 
                    if (platforms[i].getStation().equals(platforms[j].getStation())) 
                    {
                    	weight = transfer_cost;
                    }
                    if (platforms[i].getTrainLine().equals("Silver") && platforms[j].getTrainLine().equals("Silver")) { weight = station_cost; }
                    DirectedEdge a = new DirectedEdge(i, j, weight);
                    dirG.addEdge(a);
                    DirectedEdge b = new DirectedEdge(j, i, weight);
                    dirG.addEdge(b);
                }
            }
        }
        return dirG;
    }

    public static void main(String args[]){
        MetroSystem mG = new MetroSystem(args[0]);
        PlatformGraph m = mG.getPlatformGraph();
        
        ShortestWPath shortestWPath = new ShortestWPath(m);
        System.out.println(shortestWPath.getEdgeWeightedDigraph());
    }
}