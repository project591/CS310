
import java.util.ArrayList;
import java.util.List;
import edu.princeton.cs.algs4.*;


public class ShortestPath {
	
   public static void main(String args[]) {
	   
	   MetroSystem mG = new MetroSystem(args[0]); 
	   Graph G = mG.getGraph(); 

	   int location = 98, destination = 24; // jfk to bowdoin
        int location2 = 98, destination2 = 3; // // jfk to Wonderland

        System.out.println("\nJFK/Umass to Bowdoin shortest path");
        System.out.println(getShortestPath(location,destination,G,mG));
        System.out.println("\nJFK/Umass to Wonderland shortest path");
        System.out.println(getShortestPath(location2,destination2,G,mG));
    }

    private static String getShortestPath(int location, int destination, Graph g, MetroSystem mG) {
        BreadthFirstPaths BFS = new BreadthFirstPaths(g, location);
        List<Station> stations = new ArrayList<Station>();
        StringBuilder builder = new StringBuilder();
       
        if (BFS.hasPathTo(destination)) {
            for (int v : BFS.pathTo(destination)) {
                stations.add(mG.stationOf(v));
            }
        } else {
            System.out.println("No paths have been found");
        }

        String train_List = stations.get(0).getStationName();
        builder.append(train_List + ": ");
        for (Station platform : stations) {
        	
            if (!platform.getTrainLines().contains(train_List)) {
            	train_List = platform.getStationName();
                builder.append("\n" + train_List + ": ");
                builder.append(platform.getStationName() + "");
            } else {
                builder.append(platform.getStationName() + " ");
            }
        }
        builder.append("");
        return builder.toString();
    }
}