// For cs310 pa4 Boston metro graph 
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import edu.princeton.cs.algs4.*;

public class StationGraph {

	private Station[] stations = null;
	private Map<String, Station> stationMap = null;
	// The graph, made available by getGraph()
	private Graph stationGraph;
	
	public StationGraph(Graph g, Map<String, Station> sMap) {
		stationGraph = g;
		stationMap = sMap;
		// create stations table for lookup by stationId
		// station ids start at 1, like the file does
		stations = new Station[stationMap.size() + 1];
		for (String s : stationMap.keySet()) {
			Station station = stationMap.get(s);
			stations[station.getStationId()] = station;
		}
	}

	public Graph getGraph() {
		return stationGraph;
	}

	public Station stationOf(int id) {
		if (id > 0 && id < stations.length) {
			return stations[id];
		} else
			return null;
	}

	public Station stationOf(String name) {
		return stationMap.get(name);
	}

	// Report on how this station is directly connected to other stations in the
	// system using the Station graph
	public void printStationNeighbors(String stationName) {
		Station station = stationMap.get(stationName);
		System.out.println("printStationNeighbors for " + stationName + ", id " + station.getStationId() + " train lines "
				+ station.getTrainLines());
		
		// what to modify here?
		for (int i : stationGraph.adj(station.getStationId())) {
			System.out.println("Neighbor station: " + stations[i].getStationName() + " id " + i + ", train lines "
					+ stations[i].getTrainLines());
		}
	}

	
	// opposite platform code. 
	
	public int oppositePlatformOf(int id) {
		int platformDir = id & 1; // last bit gives side, 0 or 1
		int oppPlatformId;
		if (platformDir == 1)
			oppPlatformId = id - 1; // clear last bit (it was on)
		else
			oppPlatformId = id + 1; // set last bit (it was off)
		return oppPlatformId;
	}	
	
	// Find end of a given train line, that is, the station
	// that has only one neighbor on the same train line
	// Two such stations exist for each line. Return the one further from
	// Government Center.
	public Station endOfLineStation(String line) {
			
		 Station last_Station = stationOf(0);
		
	        double distance = 0;
	        List<Station> finalStation = new ArrayList<Station>();
	        
	        for (int i = 1; i <=148; i++) {
	            Station current_Station = stationOf(i);
	            	            
	            if(current_Station.getTrainLines().contains(line)) {
	            	
	                if (current_Station.distanceFromBoston() > distance) {
	                               	
	                    last_Station = current_Station;
	                    distance = current_Station.distanceFromBoston();	                            
	                    
	                    finalStation.add(last_Station);	                    
	                   
	                    if(finalStation.size() == 2) {
	                    
	                    	
	                    if(line != "Silver") {
	                    double distance0 = finalStation.get(0).distanceFromBoston();
	            		double distance1 = finalStation.get(1).distanceFromBoston();
	            		return distance0 > distance1 ? finalStation.get(0) : finalStation.get(1);	
	                    }
	                    
	                    else {
	                    	
	                    	return current_Station ;
	                    	
	                    }
	                    
	                    }	                    
	                    
	                   if(line == "Blue" || line == "Mattapan" || line == "GreenD" || line == "GreenE"||line == "Orange"|| line =="RedA" || line == "RedB")
	                    {
	                    	return last_Station;
	                    }
	                  
	                }
	                
	            }     
	            
	        }	   
	        
	        
	        return null;
	}

	// Print stations on a trainline, starting from the end station that is
	// further out from central Boston, using the Station graph
	public void printTrainLine1(String trainLine) {	
		
		Station endPlatform = endOfLineStation(trainLine);
		if (endPlatform == null) {
			System.out.println("end station was not found");
			return;
		}
		int platformId = endPlatform.getStationId();
		boolean found =  false;
				
		List<String> foundStations = new ArrayList<String>();
		foundStations.add(endPlatform.getStationName()); 
		do {
			found = false;
			for (int i : stationGraph.adj(platformId)) {
				if (stationOf(i).getTrainLines().contains(trainLine)) {
					String foundStationName = stationOf(i).getStationName();
					// System.out.println("found " + foundStationName);
					if (foundStations.contains(foundStationName)) {
						continue; // don't go backwards along line
					}
					found = true;
					platformId = i; // one to use next - need to fix this
					foundStations.add(foundStationName); // prevent backtracking on line
					break; // done
				}
			}
		} while (found);
		
		if(trainLine == "Silver")
		{
			foundStations.add(0, "South Station");
		}
		
		if(trainLine == "Mattapan" || trainLine == "GreenD" || trainLine == "GreenE"||trainLine == "GreenB"|| trainLine =="RedA" || trainLine == "RedB" || trainLine =="GreenC" || trainLine == "Silver")
		{
			Collections.reverse(foundStations);
		}
		
		
		System.out.println(foundStations);	
	}

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		MetroSystem mS = new MetroSystem(args[0]); // ok so put a number here to test code. 
		StationGraph stationGraph = mS.getStationGraph();
		
		System.out.println(stationGraph.stationOf(20).getStationName());
		
		stationGraph.printStationNeighbors("NorthStation");

		//stationGraph.printTrainLine1("GreenD") ;
	}
}
