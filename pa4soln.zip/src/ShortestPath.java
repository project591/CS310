// cs310 pa4 solution: shortest path in the station graph
import edu.princeton.cs.algs4.BreadthFirstPaths;
// cs310 PA4 Step 3: Use BST to find shortest paths through our graph, i.e.
// all edges have the same cost.
// Here ShortestPath is a simple client, never instantiated as an object
// as suggested by the problem statement that it should have  "a main method in 
// which you code this task made easy by S&W support". Here I have used two
// helper methods.
// Alternatively, it's fine to create a ShortestPath object and do the
// work in a method of that object.

public class ShortestPath {

	// Output a route, grouping stations along lines
	// Sample: Charles[red]ParkStreet[Red,Green]Boylston[Green]
	private static void printRoute(StationGraph g, Iterable<Integer> itr) {
		for (Integer x : itr) {
			Station s = g.stationOf(x);
			System.out.print(s.getStationName() + s.getTrainLines());		
		}
	}

	private static void printRouteBetweenStations(StationGraph g, int fromId, int toId) {
		BreadthFirstPaths bfs = new BreadthFirstPaths(g.getGraph(), fromId);
		if (bfs.hasPathTo(toId)) {
			Iterable<Integer> itr = bfs.pathTo(toId);
			printRoute(g, itr); // (separate method not required here)
		}
	}

	public static void main(String[] args) {
		MetroSystem mS = new MetroSystem(args[0]);
		StationGraph stationGraph = mS.getStationGraph();
		// Use BFS S&W algorithm to find the shortest path between stations
		int jfkumId = stationGraph.stationOf("JFK/UMass").getStationId();
		int bowdoinId = stationGraph.stationOf("Bowdoin").getStationId();
		printRouteBetweenStations(stationGraph,jfkumId, bowdoinId);
		System.out.println();
		int wonderlandId = stationGraph.stationOf("Wonderland").getStationId();
		printRouteBetweenStations(stationGraph,jfkumId, wonderlandId);	
		System.out.println();
	}
}
