import edu.princeton.cs.algs4.DijkstraSP;
import edu.princeton.cs.algs4.DirectedEdge;
import edu.princeton.cs.algs4.EdgeWeightedDigraph;

import java.util.HashSet;
import java.util.Set;

import edu.princeton.cs.algs4.Digraph;

// cs310 PA4 Step 5: Use Dijkstra's algorithm to route through the metro with
// 7-minute costing of transfers from one trainline to another in a single staion,
// vs. 1 minute cost of other edges 
// This solution uses a client class that is instantiated, so that its methods
// are object methods, not static methods. This is not required here--you could
// use static methods as was done in ShortestPath
public class ShortestWPath {
	private PlatformGraph pG;

	public ShortestWPath(PlatformGraph pG) {
		this.pG = pG;
	}

	// Special-purpose graph converter from undirected to equivalent directed graph
	// It uses the platform's setup to decide on appropriate weights to use
	// weight = 1 unless edge goes from one platform to another in the same station
	// in which case weight = 7
	public EdgeWeightedDigraph edgeWeightedDigraphFromPlatformGraph() {
		Digraph G = pG.getDigraph();
		EdgeWeightedDigraph dg = new EdgeWeightedDigraph(G.V());
		// This ends up with duplicate (parallel) edges, but that doesn't
		// affect our results because the best paths use only one of the dups
		// To avoid dups, only process cases with i < j, say.
		for (int i = 2; i < G.V(); i++) {
			for (int j : G.adj(i)) {
				double weight = 1; // for edges not contained in a certain station
				// check if the edge goes from one platform to another in the same station
				// in that case, assign weight 7
				if (pG.platformOf(i).getStation().getStationName()
						.equals(pG.platformOf(j).getStation().getStationName())) {
					weight = 7; // TODO: make into class constant
				} else if (pG.platformOf(i).getTrainLine().equals("Silver"))
					weight = 3; // not really rapid transit
				DirectedEdge e1 = new DirectedEdge(i, j, weight);
//				if (i == 189 || j == 189)
//					System.out.println("Andrew: " + "i = " + i + "j= " + j);
				dg.addEdge(e1);
			}
		}
		return dg;
	}

	// get platforms for station name
	public Set<Platform> lookupStation(String stationName) {
		Set<Platform> platforms = new HashSet<Platform>();
		for (int i = 2; i < pG.getDigraph().V(); i++) {
			Platform p = pG.platformOf(i);
			if (p.getStation().getStationName().equals(stationName))
				platforms.add(p);
		}
		return platforms;
	}

	// Output a route, grouping stations along lines
	// Sample: Charles[red]ParkStreet[Red,Green]Boylston[Green]
	public void printRoute(Iterable<DirectedEdge> itr) {
		Station last = null;
		for (DirectedEdge x : itr) {
			Platform p = pG.platformOf(x.from());
		//	System.out.println("printRoute got p = " + p);
			last = pG.platformOf(x.to()).getStation();
			System.out.print(p.getStation().getStationName() + p.getStation().getTrainLines());
		}
		System.out.println(last.getStationName() + last.getTrainLines());
	}

	public static void main(String[] args) {
		MetroSystem mS = new MetroSystem(args[0]);

		ShortestWPath swp = new ShortestWPath(mS.getPlatformGraph());
		Set<Platform> umbPlatforms = swp.lookupStation("JFK/UMass");
		EdgeWeightedDigraph dg = swp.edgeWeightedDigraphFromPlatformGraph();
		System.out.println("found " + umbPlatforms.size() + " atJFK/UM ");
		Set<Platform> wonderlandPlatforms = swp.lookupStation("Wonderland");
		double minDist = 100;
		Iterable<DirectedEdge> minPath = null;
		for (Platform p : umbPlatforms) {
			int umbVertex = p.getPlatformId();
			DijkstraSP dsp1 = new DijkstraSP(dg, umbVertex);
			for (Platform q : wonderlandPlatforms) {

				int wonVertex = q.getPlatformId();

				// System.out.println("dg: " + dg);

				// System.out.println("got dsp " + dsp1);

//			for (int i = 2; i < dg.V(); i++) {
//				if (dsp.distTo(i) < 100) {
//					System.out.println(
//							"i; " + i + " of " + mS.getPlatformGraph().platformOf(i).getStation().getStationName()
//									+ " distTO:" + dsp.distTo(i));
//				}
//			}
				System.out.println("dist: " + dsp1.distTo(wonVertex));
				if (dsp1.distTo(wonVertex) < minDist) {
					minDist = dsp1.distTo(wonVertex);
					minPath = dsp1.pathTo(wonVertex);
				}
			}
		}
		swp.printRoute(minPath);
		// Platform andrew = swp.lookupStation("Andrew");
		// System.out.println("found Andree: "+ andrew);
		// swp.printRoute(dsp.pathTo(andrew.getPlatformId()));
		Set<Platform> bowdoinPlatforms = swp.lookupStation("Bowdoin");
		System.out.println("found Bowdoin: " + bowdoinPlatforms);
		//swp.printRoute(dsp.pathTo(bowdoin.getPlatformId()));
		System.out.println();

		// swp.printRoute(dsp.pathTo(wonderland.getPlatformId()));
		System.out.println();
	}
}
