
// For cs310 pa4 Boston metro graph 
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import edu.princeton.cs.algs4.*;

public class StationGraph {

	private Station[] stations = null;
	private Map<String, Station> stationMap = null;
	// The graph, made available by getGraph()
	private Graph stationGraph;

	public StationGraph(Graph g, Map<String, Station> sMap) {
		stationGraph = g;
		stationMap = sMap;		
		// create stations table for lookup by stationId
		// station ids start at 1, like the file does
		stations = new Station[stationMap.size() + 1];
		for (String s : stationMap.keySet()) {
			Station station = stationMap.get(s);
			stations[station.getStationId()] = station;
		}
	}
	
	public Graph getGraph() {
		return stationGraph;
	}

	public Station stationOf(int id) {
		if (id > 0 && id < stations.length) {
			return stations[id];
		} else
			return null;
	}
	
	public Station stationOf(String name) {
		return stationMap.get(name);
	}
	
	// Report on how this station is directly connected to other stations in the
	// system using the Station graph
	public void printStationNeighbors(String stationName) {
	
		Station station = stationMap.get(stationName);
		if (station == null) {
			System.out.println("printStationNeighbors: can't find station " + stationName);	
			return;
		}
		System.out.println("printStationNeighbors for " + stationName + ", id " + station.getStationId() + " train lines "
				+ station.getTrainLines());
		for (int i : stationGraph.adj(station.getStationId())) {
			System.out.println("Neighbor station: " + stations[i].getStationName() + "id " + i + ", train lines "
					+ stations[i].getTrainLines());
		}
	}

	// Find end of a given train line, that is, the station
	// that has only one neighbor on the same train line
	// Two such stations exist for each line. Return the one further from
	// Government Center.
	public Station endOfLineStation(String line) {
		System.out.println("endOfLineStation for " + line);
		Station endStations[] = new Station[2]; // two ends
		int endStationsIndex = 0;
		for (int i = 1; i < stationGraph.V(); i++) {
			Station s = stationOf(i);
			if (i != s.getStationId())
				System.out.println("bad id");
			if (!s.getTrainLines().contains(line))
				continue;
			// System.out.println("considering " + s.getStationName());
			int count = 0;

			for (int n : stationGraph.adj(i)) {
				Station ns = stationOf(n);
				//System.out.println("found neighbor station " + ns.getStationName());
				if (ns.getTrainLines().contains(line))
					count++;
			}
			if (count == 1) {  // looks good for end station
				if (endStationsIndex > 1) {
					System.out.println("too many end stations");
					return null;
				}
				System.out.println("found end station " + s.getStationName());
				endStations[endStationsIndex++] = s;
			} else if (count > 2) {
				System.out.println("too many neighbors on line");
			}
		}
		if (endStationsIndex != 2) {
			System.out.println("line doesn't have 2 ends: circular?");
		}
		// OK have 2 endstations, find further one out and return it
		double distance0 = endStations[0].distanceFromBoston();
		double distance1 = endStations[1].distanceFromBoston();
		return distance0 > distance1 ? endStations[0] : endStations[1];
	}

	// Print stations on a trainline, starting from the end station that is
	// further out from central Boston, using the Station graph
	public void printTrainLine1(String trainLine) {
		System.out.println("printTrainLine1 for " + trainLine);
		Station endStation = endOfLineStation(trainLine);
		if (endStation == null) {
			System.out.println("end station not found");
			return;
		}
		int stationId = endStation.getStationId();
		// tricky part: avoid choosing previously-visited stations, so track them
		boolean found = false;
		List<String> foundStations = new ArrayList<String>();
		foundStations.add(endStation.getStationName());
		do {
			found = false;
			for (int i : stationGraph.adj(stationId)) {
				if (stationOf(i).getTrainLines().contains(trainLine)) {
					String foundStationName = stationOf(i).getStationName();
					// System.out.println("found " + foundStationName);
					if (foundStations.contains(foundStationName)) {
						continue; // don't go backwards along line
					}
					found = true;
					stationId = i; // one to use next
					foundStations.add(foundStationName); // prevent backtracking on line
					break; // done
				}
			}
		} while (found);
		System.out.println(foundStations);
	}

	public static void main(String[] args) {
		MetroSystem mS = new MetroSystem(args[0]);
		StationGraph stationGraph = mS.getStationGraph();
		Set<String> lines = mS.findAllLines();
		for (String line : lines) {
			System.out.print(line + ":");
			Station s = stationGraph.endOfLineStation(line);
			if (s != null)
				System.out.println("End station is at " + s.getStationName());
			else
				System.out.println("got null for endOfLineStation");
			stationGraph.printTrainLine1(line);

		}
	//	stationGraph.printTrainLine1("GreenB");
		stationGraph.printStationNeighbors("JFK/UMass");
		//Station s1 = stationGraph.endOfLineStation("Red");
		//System.out.println("endOfLineStation for Red: " + s.getStationName());
	}
}


