package cs310;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeSet;

public class SpellChecker {
	
	// Inner class that will hold the dictionary words  
	// and process the words in file with correct and incorrectly spelled words. 
	public static class dictionary {
        static HashMap<Integer, String> dictionary_words = new HashMap<>();
        static String letters = "abcdefghijklmnopqrstuvwxyz";
        public static void put(int line, String word) {
            dictionary_words.put(line, word);
        }

        public static boolean contains(String words) {
            return (dictionary_words.containsValue(words)); 
        }      
        
        public static TreeSet<String> fixingWords(String words){
        	
        TreeSet<String> possibleWords = new TreeSet<String>();

        StringBuilder builder = new StringBuilder(words);
        
        char[] alphabet = letters.toCharArray();

        for(int i = 0; i< builder.length(); i++) {

        for (char string : alphabet) {

        StringBuilder fixedWords = new StringBuilder(builder.toString());

        fixedWords.insert(i, string);

        if(dictionary.contains(fixedWords.toString().toLowerCase())) {

        possibleWords.add(fixedWords.toString());

        	}

          }

        }

        for(int i=0; i < builder.length(); i++) {

        for (char string : alphabet) {

        StringBuilder suggest = new StringBuilder(builder.toString());

        suggest.replace(i, i+1, "");

        if(dictionary.contains(suggest.toString().toLowerCase())) {

        possibleWords.add(suggest.toString());

        }

        }

        }
                
		return possibleWords;
      }        
    }

    public static void main(String[] args) {

    	
        File textList = new File(args[0]);
    	File wordsList = new File(args[1]);
    	
        // o(n^2)
        try {
			BufferedReader br = new BufferedReader(new FileReader(wordsList));
            int counter = 0;
            // loading the dictionary here
            for (String line; (line = br.readLine()) != null; ) {
                
                dictionary.put(counter, line.toLowerCase());
                ++counter;
            }
            int lineCounter = 1; 
            br = new BufferedReader(new FileReader(textList));
            for (String line; (line = br.readLine()) != null; ) {
                String[] stringArray = line.split("\\s+");

                for (String word : stringArray) {
                    word = word.replaceAll("[^\\w'-]", "").toLowerCase(); 
                    if (!dictionary.contains(word)) {
                        TreeSet<String> suggest2 = dictionary.fixingWords(word);
                        
                        if (suggest2.size() > 0) {
                                                    	
                            System.out.printf(word + ": (line " + lineCounter
                                    + ") suggestions: " + suggest2 + "\n");
                        } else {
                            System.out.printf("%s: (line %d) misspelled: [no corrections]\n",
                                    word, lineCounter);
                        }
                    }
                }
                ++lineCounter;
            }
        } catch (Exception e) {
            System.err.println(e.getMessage()); 
        }
    }
}