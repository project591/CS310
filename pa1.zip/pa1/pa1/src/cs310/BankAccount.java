package cs310;

public class BankAccount implements Account {
	// constructor - create a BA
	    public BankAccount(String nm, int _id, int bal) { id = _id;}
	// Account API functions
	    public int withdraw(int amt) { return balance; }
	public void deposit(int amt) {}
	    public int getBalance() { return balance;}
	// Fields - all private
	private int id;
	private String name;
	private int balance;
	}
