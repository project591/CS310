package cs310;

// So what to do now.

interface JavaTokenizer {
	
	public int getLineNumber();
	
    public int getErrorCount();
	 
	public char getNextOpenClose();
	
	public String getNextID();		
	
	public String skippedText(); // Will be for part 4, Annotator
}
