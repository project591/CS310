package cs310;

public interface Account {

}
