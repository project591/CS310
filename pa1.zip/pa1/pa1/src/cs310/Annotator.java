package cs310;

import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class Annotator{
	
	
	// Simply display the whole right here for now. 
	// The use the Tokonizer function, along with the new
	// skippedText() method to get what output you need. 
	// Use the Box.java as an input file. 
	
	public Annotator (Tokenizer value)
    {
		// will equal the value that is in here.  
        tok = value; 
    }
	
	private Tokenizer tok;
	
	public void generateCrossReference( )
	    {
	       Map<String,List<Integer>> theIdentifiers = new TreeMap<String,List<Integer>>( );
	       String current;
            // Insert identifiers into the search tree
        while( (current = tok.getNextID( ) ) != "" )
        {
            List<Integer> lines = theIdentifiers.get( current );
            if( lines == null )
            {
                lines = new ArrayList<Integer>( );
                theIdentifiers.put( current, lines );
            }
            lines.add( tok.getLineNumber( ));
        }
	         
        String holder = tok.skippedText();
                
        System.out.println(holder);     
    }

	
	public static void main( String [ ] args ) {
	
		Annotator p;
		
        p = new Annotator( new Tokenizer(new InputStreamReader( System.in )));
        p.generateCrossReference(); // See if it does anything. 
        
	}	
}
	
