package cs310;

public class Box {
	 
	
	// count of something
  private int count;
  // inc method 
  public void increment() {
      count++;  // line comment
  }
  public int getCount() { return count;}
}
