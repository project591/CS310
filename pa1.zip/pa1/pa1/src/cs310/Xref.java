package cs310;
// https://users.cs.fiu.edu/%7Eweiss/dsj4/code/Xref.java
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.FileReader;
import java.io.Reader;

import java.util.Iterator;
import java.util.TreeMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

// Xref class interface: generate cross-reference
//
// CONSTRUCTION: with a Reader object
// ******************PUBLIC OPERATIONS***********************
// void generateCrossReference( ) --> Name says it all ...
// ******************ERRORS**********************************
// Error checking on comments and quotes is performed
// main generates cross-reference.


/**
 * Class to perform cross reference
 * generation for Java programs.
 */
public class Xref 
{
    /**
     * Constructor.
     * @param tokenizer the stream containing a program.
     */
	
	// so implementing everything with a new method. How would that work.
	// Ok so fix the main. This could work
	public Xref (JavaTokenizer value)
    {
		// will equal the value that is in here. 
        tok = value; 
    }


    private JavaTokenizer tok;//tokenizer object somehow no error

    /**
     * Output the cross reference.
     */
    public void generateCrossReference( )
    {
        Map<String,List<Integer>> theIdentifiers = new TreeMap<String,List<Integer>>( );
        String current;

            // Insert identifiers into the search tree
        while( ( current = tok.getNextID( ) ) != "" )
        {
            List<Integer> lines = theIdentifiers.get( current );
            if( lines == null )
            {
                lines = new ArrayList<Integer>( );
                theIdentifiers.put( current, lines );
            }
            lines.add( tok.getLineNumber( ) );
        }
        
            // Iterate through search tree and output
            // identifiers and their line number
			
        for( Map.Entry<String,List<Integer>> thisNode : theIdentifiers.entrySet( ) )
        {
            Iterator<Integer> lineItr = thisNode.getValue( ).iterator( );

                // Print identifier and first line where it occurs
            System.out.print( thisNode.getKey( ) + ": " );
            System.out.print( lineItr.next( ) );
            
                // Print all other lines on which it occurs
            while( lineItr.hasNext( ) )
                System.out.print( ", " + lineItr.next( ) );
            System.out.println( );    
        }    
    }

    /**
     * main routine to generate cross-reference.
     * If no command line parameters, standard input is used.
     * Otherwise, files in command line are used.
     */
    public static void main( String [] args )
    {
    	Xref p;
    	
    	System.out.println("Starting...");																		
        if( args.length == 0 )
        {
            p = new Xref( new Tokenizer(new InputStreamReader( System.in )));
            p.generateCrossReference( );

            return;
        } else System.out.println("Xref usage: java Xref < inputfile");
     }
}